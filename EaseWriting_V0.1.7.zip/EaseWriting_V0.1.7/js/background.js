const headerKey = "x-es-flag";
const requestUrls = [
  "https://www.jianshu.com/*",
  "https://upload-images.jianshu.io/*",
  "https://api.juejin.cn/*",
  "https://juejin.cn/*",
  "https://segmentfault.com/*",
  "https://bizapi.csdn.net/*",
  "https://imgservice.csdn.net/*",
  "https://baijiahao.baidu.com/*",
];
const responseUrls = [
  "https://upload-images.jianshu.io/*",
  "https://csdn-img-blog.oss-cn-beijing.aliyuncs.com/*",
  "https://imgservice.csdn.net/*",
  "https://juejin.cn/*",
  "https://zhuanlan.zhihu.com/*",
  "https://baijiahao.baidu.com/*",
];
const siteConfig = {
  jianshu: {
    cookie: {
      domain: ".jianshu.com",
    },
    headers: [
      {
        name: "Referer",
        value: "https://www.jianshu.com/writer",
      },
      {
        name: "Origin",
        value: "https://www.jianshu.com",
      },
      {
        name: "Content-Type",
        value: "application/json; charset=UTF-8",
      },
      {
        name: "Accept",
        value: "application/json",
      },
    ],
  },
  csdn: {
    cookie: {
      domain: ".csdn.net",
    },
    headers: [
      {
        name: "origin",
        value: "https://editor.csdn.net",
      },
      {
        name: "Referer",
        value: "https://editor.csdn.net/md",
      },
    ],
  },
  segmentfault: {
    cookie: {
      domain: ".segmentfault.com",
    },
    headers: [
      {
        name: "Referer",
        value: "https://segmentfault.com/write?freshman=1",
      },
      {
        name: "origin",
        value: "https://segmentfault.com",
      },
    ],
  },
  juejin: {
    cookie: {
      domain: ".juejin.cn",
    },
    headers: [
      {
        name: "Referer",
        value: "https://juejin.cn",
      },
      {
        name: "Origin",
        value: "https://juejin.cn",
      },
    ],
  },
  baidu: {
    headers: [
      {
        name: "Host",
        value: "baijiahao.baidu.com",
      },
      {
        name: "Origin",
        value: "https://baijiahao.baidu.com",
      },
      {
        name: "Referer",
        value: "https://baijiahao.baidu.com",
      },
    ],
  },
};
// base64转blob
function base64ByBlob(base64, callback) {
  return new Promise((res) => {
    const arr = base64.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    res(new Blob([u8arr], { type: mime }));
    callback && callback(new Blob([u8arr], { type: mime }));
  });
}
// 判断是否是需要运行的网站 TODO:
function siteCheck({ requestHeaders, responseHeaders }) {
  const headers = requestHeaders || responseHeaders;
  return headers.some((item) => {
    return item.name === headerKey;
  });
  // chrome.tabs.getCurrent(function(tab){

  //   console.log(tab.title);

  //   console.log(tab.url);

  //   })
  // return true;
  return /http(s?):\/\/(www.)?(easewrite\.cn|localhost).*/.test(url);
}
chrome.runtime.onMessageExternal.addListener(function (
  request,
  sender,
  sendResponse
) {
  // 校验连接
  if (request === "VerifyConnection") {
    sendResponse(true);
  } else {
    // console.log(request);
    let sendResponsePlus = {
      error: (message) => {
        sendResponse({ ok: false, message });
      },
      success: (data) => {
        sendResponse({ ok: true, data, url: data.url });
      },
      send: (data) => {
        sendResponse(data);
      },
    };
    eval(request.handelFetch);
    if (request.config) {
      request.config.headers = request.config.headers || {};
      request.config.headers[headerKey] = "es";
    }
    fetchFun(sendResponsePlus, request.config);
  }
});
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const { url } = details;
    if (!siteCheck(details)) return {};
    const domainKey = Object.keys(siteConfig).find((item) =>
      url.includes(item)
    );
    if (!domainKey) return {};
    if (siteConfig[domainKey].cookie) {
      const { domain, value } = siteConfig[domainKey].cookie;
      const hasCookieHeader = details.requestHeaders.find((item) => {
        return item.name.toLowerCase === "cookie";
      });
      if (!hasCookieHeader) {
        if (domain)
          chrome.cookies.getAll(
            {
              domain,
            },
            function (cookie) {
              siteConfig[domainKey].cookie.value = cookie.reduce(
                (res, item, index) => {
                  res += `${index > 0 ? "; " : ""}${item.name}=${item.value}`;
                  return res;
                },
                ""
              );
            }
          );
        if (value)
          details.requestHeaders.push({
            name: "Cookie",
            value: value,
          });
      } else {
        siteConfig[domainKey].cookie.value = hasCookieHeader.value;
      }
    }
    // 添加headers
    if (siteConfig[domainKey].headers) {
      details.requestHeaders.push(...siteConfig[domainKey].headers);
    }
    return { requestHeaders: details.requestHeaders };
  },
  {
    urls: requestUrls,
    types: ["xmlhttprequest"],
  },
  ["blocking", "requestHeaders", "extraHeaders"]
);
chrome.webRequest.onHeadersReceived.addListener(
  function (details) {
    // if (!siteCheck(details)) return {};
    const responseHeaders = details.responseHeaders.filter(
      (item) => item.name.toLowerCase() !== "access-control-allow-origin"
    );
    // TODO: 根据不同的 header 处理跨域
    responseHeaders.push({
      name: "Access-Control-Allow-Origin",
      // value: "*",
      // value: "http://localhost:3000",
      value: "https://easewriting.com",
    });
    return { responseHeaders: responseHeaders };
  },
  { urls: responseUrls },
  ["blocking", "responseHeaders"]
);
