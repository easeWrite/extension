let event = new CustomEvent("EaseWriteId", {
  detail: {
    id: chrome.runtime.id,
    version: chrome.runtime.getManifest().version,
  },
});
window.dispatchEvent(event);
